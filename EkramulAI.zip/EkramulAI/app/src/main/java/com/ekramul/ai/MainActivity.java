package com.ekramul.ai;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.speech.RecognizerIntent;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.app.AlertDialog.Builder;
import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQ_MIC = 21, REQ_SPEECH = 22;
    private SharedPreferences prefs;
    private TextView chatText, statusText;
    private EditText input;
    private TextToSpeech tts;
    private GeminiClient gemini;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("ekramul_settings", MODE_PRIVATE);
        chatText = findViewById(R.id.chatText);
        statusText = findViewById(R.id.statusText);
        input = findViewById(R.id.messageInput);
        gemini = new GeminiClient(this);
        tts = new TextToSpeech(this, result -> {
            if (result == TextToSpeech.SUCCESS) {
                tts.setLanguage(new Locale("bn", "BD"));
                // Android uses the best available installed voice; a female voice is not guaranteed.
            }
        });
        findViewById(R.id.settingsButton).setOnClickListener(v -> showApiSettings());
        findViewById(R.id.sendButton).setOnClickListener(v -> sendMessage());
        findViewById(R.id.voiceButton).setOnClickListener(v -> startVoice());
        findViewById(R.id.floatButton).setOnClickListener(v -> enableFloating());
        refreshStatus();
    }

    private void refreshStatus() {
        statusText.setText(prefs.getString("api_key", "").isEmpty()
                ? "API key required" : "API key saved — connection not yet verified");
    }

    private void showApiSettings() {
        EditText key = new EditText(this);
        key.setSingleLine(true);
        key.setHint("Paste Gemini API key");
        key.setText(prefs.getString("api_key", ""));
        new Builder(this).setTitle("Gemini API Settings")
            .setMessage("Add or replace your Gemini API key. The app will discover models available to this key.")
            .setView(key)
            .setPositiveButton("Save & Test", (d, w) -> {
                String value = key.getText().toString().trim();
                if (value.isEmpty()) { Toast.makeText(this, "API key is empty", Toast.LENGTH_SHORT).show(); return; }
                prefs.edit().putString("api_key", value).apply();
                gemini.testConnection((ok, message) -> runOnUiThread(() -> {
                    statusText.setText(ok ? "Connected" : "Connection failed");
                    Toast.makeText(this, message, Toast.LENGTH_LONG).show();
                }));
            })
            .setNeutralButton("Delete key", (d,w) -> {
                prefs.edit().remove("api_key").apply(); refreshStatus();
            })
            .setNegativeButton("Cancel", null).show();
    }

    private void sendMessage() {
        String message = input.getText().toString().trim();
        if (message.isEmpty()) return;
        input.setText("");
        append("You: " + message + "\n\nEkramul AI: ");
        gemini.ask(message, (ok, answer) -> runOnUiThread(() -> {
            if (ok) {
                append(answer + "\n\n");
                if (prefs.getBoolean("speak_replies", true) && tts != null)
                    tts.speak(answer, TextToSpeech.QUEUE_FLUSH, null, "ekramul_reply");
            } else append("Error: " + answer + "\n\n");
        }));
    }
    private void append(String s) { chatText.append(s); }

    private void startVoice() {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, REQ_MIC);
            return;
        }
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD");
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak to Ekramul AI");
        try { startActivityForResult(i, REQ_SPEECH); }
        catch (Exception e) { Toast.makeText(this, "Speech recognition is unavailable on this device", Toast.LENGTH_LONG).show(); }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_SPEECH && resultCode == RESULT_OK && data != null) {
            ArrayList<String> results = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
            if (results != null && !results.isEmpty()) { input.setText(results.get(0)); sendMessage(); }
        }
    }

    private void enableFloating() {
        if (!Settings.canDrawOverlays(this)) {
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
            Toast.makeText(this, "Allow display over other apps, then tap Float again", Toast.LENGTH_LONG).show();
            return;
        }
        startService(new Intent(this, FloatingAssistantService.class));
        Toast.makeText(this, "Floating Ekramul AI enabled", Toast.LENGTH_SHORT).show();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_MIC && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
            startVoice();
    }
    @Override protected void onDestroy() {
        if (tts != null) { tts.stop(); tts.shutdown(); }
        super.onDestroy();
    }
}
