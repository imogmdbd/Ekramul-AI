package com.ekramul.ai;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.IBinder;
import android.view.Gravity;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.Toast;
import android.view.MotionEvent;
import android.provider.Settings;

public class FloatingAssistantService extends Service {
    private WindowManager wm;
    private ImageView bubble;
    private WindowManager.LayoutParams params;
    @Override public void onCreate() {
        super.onCreate();
        if (!Settings.canDrawOverlays(this)) { stopSelf(); return; }
        wm=(WindowManager)getSystemService(WINDOW_SERVICE);
        bubble=new ImageView(this);
        bubble.setImageResource(R.drawable.ekramul_logo);
        bubble.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int type=WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY;
        params=new WindowManager.LayoutParams(76,76,type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT);
        params.gravity=Gravity.TOP|Gravity.START; params.x=30; params.y=180;
        bubble.setOnTouchListener(new android.view.View.OnTouchListener() {
            float downX,downY; int startX,startY;
            public boolean onTouch(android.view.View v, MotionEvent e) {
                if(e.getAction()==MotionEvent.ACTION_DOWN){ downX=e.getRawX(); downY=e.getRawY(); startX=params.x; startY=params.y; return true; }
                if(e.getAction()==MotionEvent.ACTION_MOVE){ params.x=startX+(int)(e.getRawX()-downX); params.y=startY+(int)(e.getRawY()-downY); wm.updateViewLayout(bubble,params); return true; }
                if(e.getAction()==MotionEvent.ACTION_UP){ if(Math.abs(e.getRawX()-downX)<10 && Math.abs(e.getRawY()-downY)<10) Toast.makeText(thisService(), "Open Ekramul AI to chat or use voice", Toast.LENGTH_SHORT).show(); return true; }
                return true;
            }
        });
        try { wm.addView(bubble,params); } catch(Exception e){ stopSelf(); }
    }
    private Service thisService(){ return this; }
    @Override public void onDestroy(){ if(wm!=null && bubble!=null) try{wm.removeView(bubble);}catch(Exception ignored){} super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
