package com.ekramul.ai;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class GeminiClient {
    public interface Callback { void done(boolean success, String result); }
    private final SharedPreferences prefs;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private static final String BASE = "https://generativelanguage.googleapis.com/v1beta/";

    public GeminiClient(Context c) {
        prefs = c.getSharedPreferences("ekramul_settings", Context.MODE_PRIVATE);
    }
    private String request(String path, String key, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection)new URL(BASE + path).openConnection();
        c.setRequestMethod(body == null ? "GET" : "POST");
        c.setConnectTimeout(20000); c.setReadTimeout(30000);
        c.setRequestProperty("x-goog-api-key", key);
        if (body != null) {
            c.setDoOutput(true); c.setRequestProperty("Content-Type","application/json; charset=utf-8");
            try(OutputStream os=c.getOutputStream()){ os.write(body.getBytes(StandardCharsets.UTF_8)); }
        }
        int code=c.getResponseCode();
        InputStream is=(code>=200 && code<300)?c.getInputStream():c.getErrorStream();
        ByteArrayOutputStream out=new ByteArrayOutputStream();
        if(is!=null){ byte[] b=new byte[4096]; int n; while((n=is.read(b))!=-1) out.write(b,0,n); is.close(); }
        String response=out.toString("UTF-8"); c.disconnect();
        if(code<200 || code>=300) throw new IOException("HTTP "+code+": "+response);
        return response;
    }
    private String discoverModel(String key) throws Exception {
        JSONObject list=new JSONObject(request("models?pageSize=100",key,null));
        JSONArray models=list.optJSONArray("models");
        if(models==null) throw new IOException("No models returned for this API key.");
        String fallback=null;
        for(int i=0;i<models.length();i++){
            JSONObject m=models.getJSONObject(i);
            String name=m.optString("name","");
            JSONArray methods=m.optJSONArray("supportedGenerationMethods");
            boolean generate=false;
            if(methods!=null) for(int j=0;j<methods.length();j++)
                if("generateContent".equals(methods.optString(j))) generate=true;
            if(generate && name.startsWith("models/") && !name.toLowerCase().contains("embedding")) {
                if(fallback==null) fallback=name.substring("models/".length());
                String low=name.toLowerCase();
                if(low.contains("flash") && !low.contains("preview") && !low.contains("experimental")) return name.substring(7);
            }
        }
        if(fallback!=null) return fallback;
        throw new IOException("This API key has no model supporting generateContent.");
    }
    public void testConnection(Callback cb) {
        worker.execute(() -> {
            try {
                String key=prefs.getString("api_key","");
                if(key.isEmpty()) throw new IOException("Add a Gemini API key first.");
                String model=discoverModel(key);
                prefs.edit().putString("active_model",model).apply();
                cb.done(true,"Connected. Available model selected: "+model);
            } catch(Exception e){ cb.done(false,e.getMessage()==null?"Connection failed":e.getMessage()); }
        });
    }
    public void ask(String prompt, Callback cb) {
        worker.execute(() -> {
            try {
                String key=prefs.getString("api_key","");
                if(key.isEmpty()) throw new IOException("Add your Gemini API key in API Settings.");
                String model=prefs.getString("active_model","");
                if(model.isEmpty()) model=discoverModel(key);
                JSONObject part=new JSONObject().put("text",prompt);
                JSONObject content=new JSONObject().put("parts",new JSONArray().put(part));
                JSONObject body=new JSONObject().put("contents",new JSONArray().put(content));
                String response=request("models/"+model+":generateContent",key,body.toString());
                JSONObject root=new JSONObject(response);
                JSONArray candidates=root.optJSONArray("candidates");
                if(candidates==null || candidates.length()==0) throw new IOException("Gemini returned no answer.");
                StringBuilder answer=new StringBuilder();
                JSONArray parts=candidates.getJSONObject(0).getJSONObject("content").getJSONArray("parts");
                for(int i=0;i<parts.length();i++) answer.append(parts.getJSONObject(i).optString("text",""));
                cb.done(true,answer.toString());
            } catch(Exception e){ cb.done(false,e.getMessage()==null?"Request failed":e.getMessage()); }
        });
    }
}
