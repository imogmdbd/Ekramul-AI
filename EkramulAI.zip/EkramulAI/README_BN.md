# Ekramul AI — Android Java starter project

**App name:** Ekramul AI  
**Package:** `com.ekramul.ai`  
**Language:** Java  
**UI:** XML  
**AI:** Google Gemini API (models are discovered from the supplied API key)  
**Firebase:** Not included

## Build requirements
- Android Studio or Termux with JDK 17
- Android SDK Platform 35 and Build Tools
- Gradle 8.9 (wrapper can be generated with `gradle wrapper --gradle-version 8.9`)

## Termux build
```bash
pkg update -y
pkg install openjdk-17 gradle unzip -y
termux-setup-storage
cd /storage/emulated/0/Download
unzip -o EkramulAI.zip
cd EkramulAI
export JAVA_HOME=$PREFIX/lib/jvm/java-17-openjdk
export PATH=$JAVA_HOME/bin:$PATH
# Set sdk.dir in local.properties to your actual Android SDK path
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk`

## Current implementation
- XML-based dark chat screen and locally bundled launcher/floating logo.
- Gemini API key save/delete and connection test.
- Model discovery through the Gemini `models` endpoint; selects a model that advertises `generateContent` support (prefers a stable Flash model when returned).
- Text chat through Gemini.
- Android speech-recognition intent and system TextToSpeech (voice gender depends on installed device voices).
- Movable overlay bubble after the user grants overlay permission.

## Important limitations
This is a starter source project, not a certified production release. It has not been built or device-tested in this environment. Accessibility-based universal app control, full chat history/memory, multiple-key rotation, true interruptible full-duplex voice, ripple states, and release signing still need implementation and device testing. Android may restrict actions in protected app screens. Client-side API keys cannot be made completely extraction-proof.
