# Ekramul AI — patched Android starter project

This is Android source code, not an APK. The ZIP includes a GitHub Actions workflow that can build a debug APK in the cloud.

## Build using only your phone
1. Create/sign in to a GitHub account in your phone browser or GitHub app.
2. Create a **new private repository** named `EkramulAI`.
3. Extract this ZIP on your phone (Files app → ZIP → Extract).
4. Upload the extracted project contents to the repository root. Make sure `.github/workflows/android-apk.yml` is included. If GitHub mobile upload hides dot-folders, create the workflow file in GitHub at `.github/workflows/android-apk.yml` using the contents from this ZIP.
5. Open the repository's **Actions** tab and run **Build Ekramul AI APK** (or push to `main`).
6. When the run completes successfully, open it and download the `EkramulAI-debug-apk` artifact. Extract the artifact ZIP to get `app-debug.apk`.

## Important
- The build workflow has been added, but this environment cannot run Android Gradle/SDK builds. The APK is not yet built or tested.
- A successful compilation does not prove all features work on your phone.
- Current code is a starter implementation. The Gemini backend URL is not configured; general AI conversation/complex task planning is not functional. OCR and always-on wake word are not implemented.
- Accessibility features only work where Android and the target app expose accessible UI elements. Confirm sensitive actions yourself.
- Bengali speech and TTS voice availability depend on speech/TTS services installed on the phone.
