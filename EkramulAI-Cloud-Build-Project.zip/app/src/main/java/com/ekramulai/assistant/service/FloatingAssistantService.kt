package com.ekramulai.assistant.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.TextView
import androidx.core.app.NotificationCompat
import com.ekramulai.assistant.MainActivity
import com.ekramulai.assistant.R
import com.ekramulai.assistant.voice.VoiceRecognitionManager\nimport com.ekramulai.assistant.voice.EkramulTtsManager
import kotlin.math.abs

/**
 * Android Foreground Service displaying the circular "Ekramul AI" floating overlay widget.
 * Moves smoothly across apps, handles tap-to-talk, and provides listening animations.
 */
class FloatingAssistantService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var floatingView: View
    private lateinit var params: WindowManager.LayoutParams
    private lateinit var voiceManager: VoiceRecognitionManager

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f
    private var isListening = false

    companion object {
        const val CHANNEL_ID = "ekramul_assistant_fg"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP = "com.ekramulai.action.STOP"
    }

    override fun onCreate() {
        super.onCreate()
        startForegroundNotification()
        setupFloatingView()
        setupVoiceRecognition()
    }

    private fun startForegroundNotification() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ekramul AI Assistant Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Keeps Ekramul AI ready to assist you anywhere on your phone"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }

        val openIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, openIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Ekramul AI Active")
            .setContentText("Tap floating AI widget or speak in Bengali/English")
            .setSmallIcon(R.drawable.ic_ekramul_ai)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    private fun setupFloatingView() {
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        floatingView = LayoutInflater.from(this).inflate(R.layout.layout_floating_assistant, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 100
            y = 300
        }

        windowManager.addView(floatingView, params)

        val assistantIcon = floatingView.findViewById<ImageView>(R.id.img_assistant_logo)
        val pulseRing = floatingView.findViewById<View>(R.id.view_pulse_ring)

        assistantIcon.setOnTouchListener(object : View.OnTouchListener {
            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = params.x
                        initialY = params.y
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        params.x = initialX + (event.rawX - initialTouchX).toInt()
                        params.y = initialY + (event.rawY - initialTouchY).toInt()
                        windowManager.updateViewLayout(floatingView, params)
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        val deltaX = abs(event.rawX - initialTouchX)
                        val deltaY = abs(event.rawY - initialTouchY)
                        if (deltaX < 10 && deltaY < 10) {
                            // Click detected: Toggle Voice Listening
                            toggleVoiceAssistant()
                        }
                        return true
                    }
                }
                return false
            }
        })
    }

    private fun setupVoiceRecognition() {
        voiceManager = VoiceRecognitionManager(this) { spokenText, isFinal ->
            if (isFinal) {
                isListening = false
                updateFloatingVisualState(false)
                handleVoiceCommand(spokenText)
            }
        }
    }


    private fun handleVoiceCommand(raw: String) {
        val command = raw.trim()
        if (command.isBlank()) {
            EkramulTtsManager.getInstance(this).speak("আমি শুনতে পাইনি। আবার বলুন।")
            return
        }
        val a11y = EkramulAccessibilityService.instance
        val lower = command.lowercase(java.util.Locale.ROOT)

        fun announceThen(message: String, action: () -> Boolean) {
            EkramulTtsManager.getInstance(this).speak(message) {
                val ok = try { action() } catch (_: Exception) { false }
                if (!ok) EkramulTtsManager.getInstance(this)
                    .speak("দুঃখিত, কাজটি করতে পারিনি। অনুমতি বা অ্যাপের সীমাবদ্ধতা থাকতে পারে।")
            }
        }

        when {
            lower == "back" || lower.contains("গো ব্যাক") || lower.contains("পিছনে যাও") ->
                announceThen("ঠিক আছে, ফিরে যাচ্ছি।") { a11y?.performBack() ?: false }
            lower == "home" || lower.contains("হোমে যাও") || lower.contains("হোম স্ক্রিন") ->
                announceThen("হোম স্ক্রিনে যাচ্ছি।") { a11y?.performHome() ?: false }
            lower.contains("scroll down") || lower.contains("নিচে স্ক্রল") || lower.contains("নিচে যাও") ->
                announceThen("নিচে স্ক্রল করছি।") { a11y?.scrollDown() ?: false }
            lower.contains("scroll up") || lower.contains("উপরে স্ক্রল") || lower.contains("উপরে যাও") ->
                announceThen("উপরে স্ক্রল করছি।") { a11y?.scrollUp() ?: false }
            lower.contains("click ") || lower.contains("ক্লিক") || lower.contains("চাপ দাও") -> {
                val target = command.substringAfter("click ", command.substringAfter("ক্লিক", "").substringAfter("করো", "")).trim()
                if (target.isBlank()) EkramulTtsManager.getInstance(this).speak("কোন বাটনে ক্লিক করব?")
                else announceThen("$target খুঁজে ক্লিক করছি।") { a11y?.clickElementByText(target) ?: false }
            }
            lower.startsWith("type ") || lower.startsWith("write ") || lower.startsWith("লিখে দাও ") || lower.startsWith("লেখ ") -> {
                val text = when {
                    lower.startsWith("type ") -> command.drop(5)
                    lower.startsWith("write ") -> command.drop(6)
                    lower.startsWith("লিখে দাও ") -> command.removePrefix("লিখে দাও ")
                    else -> command.removePrefix("লেখ ")
                }.trim()
                announceThen("লিখে দিচ্ছি।") { a11y?.enterText(text) ?: false }
            }
            lower.contains("read screen") || lower.contains("স্ক্রিনে কি আছে") || lower.contains("স্ক্রিন পড়ে শোনাও") -> {
                val lines = a11y?.readScreenContent().orEmpty().take(20)
                EkramulTtsManager.getInstance(this).speak(if (lines.isEmpty()) "স্ক্রিনের লেখা পড়তে পারছি না।" else lines.joinToString("। "))
            }
            lower.startsWith("open ") || lower.startsWith("ওপেন ") || lower.startsWith("খোলো ") || lower.startsWith("চালু কর ") -> {
                val appName = when {
                    lower.startsWith("open ") -> command.drop(5).trim()
                    lower.startsWith("ওপেন ") -> command.drop(5).trim()
                    lower.startsWith("খোলো ") -> command.drop(5).trim()
                    else -> command.removePrefix("চালু কর ").trim()
                }
                announceThen("$appName খুলছি।") { launchInstalledApp(appName) }
            }
            else -> EkramulTtsManager.getInstance(this)
                .speak("আমি নির্দেশটি বুঝতে পারিনি। আপাতত বলুন, অ্যাপ খোলো, ব্যাক, হোম, স্ক্রল, ক্লিক অথবা লিখে দাও।")
        }
    }

    private fun launchInstalledApp(name: String): Boolean {
        val pm = packageManager
        val matches = pm.getInstalledApplications(0).filter {
            pm.getApplicationLabel(it).toString().contains(name, ignoreCase = true)
        }
        val app = matches.firstOrNull { pm.getLaunchIntentForPackage(it.packageName) != null }
            ?: return false
        val launch = pm.getLaunchIntentForPackage(app.packageName) ?: return false
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        startActivity(launch)
        return true
    }

    private fun toggleVoiceAssistant() {
        if (!isListening) {
            isListening = true
            updateFloatingVisualState(true)
            voiceManager.startListening()
        } else {
            isListening = false
            updateFloatingVisualState(false)
            voiceManager.stopListening()
        }
    }

    private fun updateFloatingVisualState(listening: Boolean) {
        val pulseRing = floatingView.findViewById<View>(R.id.view_pulse_ring)
        val statusPill = floatingView.findViewById<TextView>(R.id.tv_assistant_status)

        if (listening) {
            pulseRing.visibility = View.VISIBLE
            statusPill.visibility = View.VISIBLE
            statusPill.text = "Listening..."
        } else {
            pulseRing.visibility = View.GONE
            statusPill.visibility = View.GONE
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::floatingView.isInitialized) {
            windowManager.removeView(floatingView)
        }
        voiceManager.destroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}