package com.ekramulai.assistant.brain

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

/**
 * Communicates with the Ekramul AI backend brain to parse user speech,
 * plan multi-step accessibility tasks, and return actionable steps.
 */
class GeminiAssistantBrain(private val backendUrl: String) {

    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    suspend fun processVoiceCommand(
        commandText: String,
        currentApp: String,
        visibleNodes: List<String>
    ): BrainResponse = withContext(Dispatchers.IO) {
        try {
            val payload = JSONObject().apply {
                put("message", commandText)
                put("currentApp", currentApp)
                put("visibleElements", visibleNodes)
            }

            val request = Request.Builder()
                .url("$backendUrl/api/assistant/process")
                .post(payload.toString().toRequestBody("application/json".toMediaType()))
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: ""
            val json = JSONObject(responseBody)

            val spokenResponse = json.optString("spokenResponse", "Okay")
            val actionsArray = json.optJSONArray("actions")
            val actionList = mutableListOf<ParsedAction>()

            if (actionsArray != null) {
                for (i in 0 until actionsArray.length()) {
                    val obj = actionsArray.getJSONObject(i)
                    actionList.add(
                        ParsedAction(
                            type = obj.getString("type"),
                            targetApp = obj.optString("targetApp"),
                            targetText = obj.optString("targetText"),
                            text = obj.optString("text"),
                            explanation = obj.optString("explanation")
                        )
                    )
                }
            }

            BrainResponse(
                spokenResponse = spokenResponse,
                actions = actionList,
                isSuccess = true
            )
        } catch (e: Exception) {
            BrainResponse(
                spokenResponse = "Error connecting to AI service. Please check network connection.",
                actions = emptyList(),
                isSuccess = false
            )
        }
    }
}

data class BrainResponse(
    val spokenResponse: String,
    val actions: List<ParsedAction>,
    val isSuccess: Boolean
)

data class ParsedAction(
    val type: String,
    val targetApp: String = "",
    val targetText: String = "",
    val text: String = "",
    val explanation: String = ""
)