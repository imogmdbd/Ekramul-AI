package com.ekramulai.assistant.service

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.util.Log
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.ekramulai.assistant.voice.EkramulTtsManager

/**
 * Genuine Android Accessibility Service for Ekramul AI.
 * Automates clicks, scrolling, text typing, app switching, and screen reading.
 */
class EkramulAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "EkramulA11yService"
        var instance: EkramulAccessibilityService? = null
            private set

        val isServiceRunning: Boolean
            get() = instance != null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.i(TAG, "Ekramul Accessibility Service connected and ready.")
        EkramulTtsManager.getInstance(applicationContext)
            .speak("Ekramul AI accessibility automation is now active.")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Track active window, packages, and interactive state changes
        if (event == null) return
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> {
                Log.d(TAG, "Foreground App Changed: ${event.packageName}")
            }
            AccessibilityEvent.TYPE_VIEW_CLICKED -> {
                Log.d(TAG, "View clicked: ${event.contentDescription ?: event.text}")
            }
        }
    }

    override fun onInterrupt() {
        Log.w(TAG, "Ekramul Accessibility Service interrupted.")
    }

    override fun onDestroy() {
        super.onDestroy()
        instance = null
        Log.i(TAG, "Ekramul Accessibility Service destroyed.")
    }

    // --- AUTOMATION ACTIONS ---

    /**
     * Finds and clicks an element matching text or content description
     */
    fun clickElementByText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val nodes = rootNode.findAccessibilityNodeInfosByText(text)
        if (nodes.isNotEmpty()) {
            for (node in nodes) {
                if (performClickOnNode(node)) {
                    Log.d(TAG, "Clicked node matching text: $text")
                    return true
                }
            }
        }
        return false
    }

    private fun performClickOnNode(node: AccessibilityNodeInfo): Boolean {
        var current: AccessibilityNodeInfo? = node
        while (current != null) {
            if (current.isClickable) {
                return current.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            }
            current = current.parent
        }
        return false
    }

    /**
     * Types text into the currently focused or first available editable field
     */
    fun enterText(text: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val focused = rootNode.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
        if (focused != null && focused.isEditable) {
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return focused.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        }

        // Fallback: search for editable fields
        val editables = mutableListOf<AccessibilityNodeInfo>()
        collectEditableNodes(rootNode, editables)
        if (editables.isNotEmpty()) {
            val target = editables.first()
            val arguments = Bundle().apply {
                putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
            }
            return target.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, arguments)
        }
        return false
    }

    private fun collectEditableNodes(node: AccessibilityNodeInfo, list: MutableList<AccessibilityNodeInfo>) {
        if (node.isEditable) {
            list.add(node)
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { collectEditableNodes(it, list) }
        }
    }

    /**
     * Performs vertical scrolling
     */
    fun scrollDown(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val scrollable = findFirstScrollableNode(rootNode)
        return scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) ?: false
    }

    fun scrollUp(): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val scrollable = findFirstScrollableNode(rootNode)
        return scrollable?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) ?: false
    }

    private fun findFirstScrollableNode(node: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (node.isScrollable) return node
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            val found = findFirstScrollableNode(child)
            if (found != null) return found
        }
        return null
    }

    /**
     * System Navigations
     */
    fun performBack(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun performHome(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun performRecents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)

    /**
     * Launches an application by package name
     */
    fun launchApp(packageName: String): Boolean {
        return try {
            val launchIntent = packageManager.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                true
            } else {
                Log.w(TAG, "Package not found: $packageName")
                false
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error launching $packageName", e)
            false
        }
    }

    /**
     * Reads all visible text on the active screen
     */
    fun readScreenContent(): List<String> {
        val rootNode = rootInActiveWindow ?: return emptyList()
        val textList = mutableListOf<String>()
        extractNodeTexts(rootNode, textList)
        return textList
    }

    private fun extractNodeTexts(node: AccessibilityNodeInfo, list: MutableList<String>) {
        val text = node.text?.toString() ?: node.contentDescription?.toString()
        if (!text.isNullOrBlank()) {
            list.add(text.trim())
        }
        for (i in 0 until node.childCount) {
            node.getChild(i)?.let { extractNodeTexts(it, list) }
        }
    }
}