package com.ekramulai.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import java.util.Locale

/**
 * Text-to-Speech manager for Ekramul AI.
 * Speaks announcements before actions are executed, supporting Bengali and English.
 */
class EkramulTtsManager private constructor(context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = TextToSpeech(context.applicationContext, this)
    private var isInitialized = false

    companion object {
        @Volatile
        private var instance: EkramulTtsManager? = null

        fun getInstance(context: Context): EkramulTtsManager {
            return instance ?: synchronized(this) {
                instance ?: EkramulTtsManager(context).also { instance = it }
            }
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isInitialized = true
            // Attempt to set Bengali locale, fallback to default English
            val bengaliLocale = Locale("bn", "BD")
            val result = tts?.setLanguage(bengaliLocale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                tts?.language = Locale.US
            }
            tts?.setSpeechRate(0.92f)
            tts?.setPitch(1.18f) // Higher pitch for a lighter, youthful-sounding voice; actual voice depends on installed TTS engine.
        } else {
            Log.e("EkramulTTS", "TTS Initialization failed")
        }
    }

    fun speak(text: String, onDone: (() -> Unit)? = null) {
        if (!isInitialized || tts == null) return

        // Auto-detect if string is Bengali or English
        val hasBengaliChar = text.any { it.code in 0x0980..0x09FF }
        if (hasBengaliChar) {
            tts?.language = Locale("bn", "BD")
        } else {
            tts?.language = Locale.US
        }

        val utteranceId = "ekramul_speech_${System.currentTimeMillis()}"
        if (onDone != null) {
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) {
                    if (id == utteranceId) onDone()
                }
                override fun onError(id: String?) {}
            })
        }

        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    }

    fun stop() {
        tts?.stop()
    }

    fun destroy() {
        tts?.shutdown()
        tts = null
        instance = null
    }
}